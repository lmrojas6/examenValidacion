<?php
	$site_url="http://localhost:50/comida";
	$local_path="C:\xampp\htdocs\examenInvestigaUTPL2022";

	define('DBHOST', '127.0.0.1');
	define('DBUSER', 'root');
	define('DBPASS', '');
	define('DBNAME', 'app1db');
?>