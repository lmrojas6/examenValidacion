		</section>
	</section>
	<footer class="piePagina">
	<h6>Derechos Reservados Ingeniería WEB 2022</h6>
		
	</footer>

</body>
</html>